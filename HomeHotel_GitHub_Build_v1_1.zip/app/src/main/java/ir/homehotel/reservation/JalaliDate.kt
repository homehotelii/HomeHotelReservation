package ir.homehotel.reservation

import android.icu.util.PersianCalendar
import android.icu.util.TimeZone
import java.util.Locale

/** Jalali date helpers backed by Android ICU's Persian calendar. */
object JalaliDate {
    private const val DAY_MS = 86_400_000L
    private fun calendar(): PersianCalendar = PersianCalendar(TimeZone.getTimeZone("UTC"))

    fun today(): String {
        val c = PersianCalendar()
        return format(c.get(PersianCalendar.YEAR), c.get(PersianCalendar.MONTH) + 1, c.get(PersianCalendar.DAY_OF_MONTH))
    }

    fun currentYearMonth(): Pair<Int, Int> {
        val c = PersianCalendar()
        return c.get(PersianCalendar.YEAR) to (c.get(PersianCalendar.MONTH) + 1)
    }

    fun format(year: Int, month: Int, day: Int): String =
        "%04d/%02d/%02d".format(Locale.US, year, month, day)

    fun parse(value: String): Triple<Int, Int, Int>? {
        val m = Regex("^(\\d{4})/(\\d{2})/(\\d{2})$").matchEntire(normalizeDigits(value)) ?: return null
        return Triple(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].toInt())
    }

    fun normalizeDigits(value: String): String = value
        .replace('۰', '0').replace('۱', '1').replace('۲', '2').replace('۳', '3').replace('۴', '4')
        .replace('۵', '5').replace('۶', '6').replace('۷', '7').replace('۸', '8').replace('۹', '9')
        .replace('٠', '0').replace('١', '1').replace('٢', '2').replace('٣', '3').replace('٤', '4')
        .replace('٥', '5').replace('٦', '6').replace('٧', '7').replace('٨', '8').replace('٩', '9')

    fun toEpochDay(value: String): Long? {
        val p = parse(value) ?: return null
        if (p.second !in 1..12 || p.third !in 1..daysInMonth(p.first, p.second)) return null
        return try {
            val c = calendar()
            c.clear()
            c.set(p.first, p.second - 1, p.third, 12, 0, 0)
            c.timeInMillis / DAY_MS
        } catch (_: Exception) { null }
    }

    fun fromEpochDay(epochDay: Long): String {
        val c = calendar()
        c.timeInMillis = epochDay * DAY_MS
        return format(c.get(PersianCalendar.YEAR), c.get(PersianCalendar.MONTH) + 1, c.get(PersianCalendar.DAY_OF_MONTH))
    }

    fun addDays(value: String, days: Int): String {
        val epoch = toEpochDay(value) ?: return today()
        return fromEpochDay(epoch + days)
    }

    fun daysInMonth(year: Int, month: Int): Int {
        val c = calendar()
        c.clear()
        c.set(year, month - 1, 1, 12, 0, 0)
        return c.getActualMaximum(PersianCalendar.DAY_OF_MONTH)
    }

    /** Saturday=0 ... Friday=6. */
    fun firstWeekdayOffset(year: Int, month: Int): Int {
        val c = calendar()
        c.clear()
        c.set(year, month - 1, 1, 12, 0, 0)
        return c.get(PersianCalendar.DAY_OF_WEEK) % 7
    }

    fun monthName(month: Int): String = listOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    ).getOrElse(month - 1) { "ماه" }

    fun persianDigits(value: String): String = value.map { ch ->
        if (ch in '0'..'9') ('۰'.code + (ch.code - '0'.code)).toChar() else ch
    }.joinToString("")
}
