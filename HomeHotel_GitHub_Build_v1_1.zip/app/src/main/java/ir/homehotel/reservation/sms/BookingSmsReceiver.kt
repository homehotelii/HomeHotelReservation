package ir.homehotel.reservation.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import ir.homehotel.reservation.data.AppDatabase
import ir.homehotel.reservation.data.Reservation
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

private const val OTAK_SENDER = "982000008800888"

class BookingSmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        val body = messages.joinToString(separator = "") { it.messageBody.orEmpty() }
        val sender = messages.firstOrNull()?.originatingAddress.orEmpty()
        if (!isOtogakSender(sender) || !body.contains("تایید رزرو") || !body.contains("قطعی شد")) return
        val parsed = parseBooking(body) ?: return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = AppDatabase.get(context).reservationDao()
                if (dao.findByCode(parsed.bookingCode) == null) dao.insert(parsed)
            } finally { pending.finish() }
        }
    }

    private fun isOtogakSender(sender: String): Boolean {
        val digits = sender.filter { it.isDigit() }
        val local = OTAK_SENDER.removePrefix("98")
        return digits == OTAK_SENDER || digits == local || digits.endsWith(local)
    }

    private fun parseBooking(raw: String): Reservation? {
        val text = normalizeDigits(raw)
        fun field(label: String): String = Regex("(?m)^${Regex.escape(label)}\\s*:\\s*(.*)$").find(text)?.groupValues?.get(1)?.trim().orEmpty()
        val code = Regex("رزرو با کد\\s*(\\d+)").find(text)?.groupValues?.get(1).orEmpty()
        val property = field("نام اقامتگاه")
        val unit = Regex("\\((\\d+)\\)\\s*$").find(property)?.groupValues?.get(1)?.toIntOrNull() ?: return null
        val checkIn = field("تاریخ ورود")
        val checkOut = field("تاریخ خروج")
        val guest = field("نام مهمان")
        if (code.isBlank() || guest.isBlank() || checkIn.isBlank() || checkOut.isBlank() || unit !in 1..4) return null
        val amount = Regex("مبلغ\\s*(\\d+)\\s*تومان").find(text)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
        val count = field("تعداد مهمان").toIntOrNull() ?: 1
        return Reservation(
            bookingCode = code, source = "اتاقک", sourceDetail = "اتاقک",
            propertyName = "ساختمان سیدخندان", propertyId = field("شناسه اقامتگاه"),
            unitNumber = unit, guestName = guest, guestPhone = field("شماره همراه مهمان"),
            checkInJalali = checkIn, checkOutJalali = checkOut, guestCount = count,
            totalAmount = amount, detailLink = field("جزئیات رزرو"), status = "در انتظار تأیید"
        )
    }

    private fun normalizeDigits(value: String): String {
        val persian = "۰۱۲۳۴۵۶۷۸۹"; val arabic = "٠١٢٣٤٥٦٧٨٩"
        return value.map { ch ->
            when { ch in persian -> '0' + persian.indexOf(ch); ch in arabic -> '0' + arabic.indexOf(ch); else -> ch }
        }.joinToString("")
    }
}
