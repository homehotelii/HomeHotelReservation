package ir.homehotel.reservation.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ReservationDao {
    @Query("SELECT * FROM reservations ORDER BY checkInJalali ASC, id DESC")
    fun observeAll(): Flow<List<Reservation>>

    @Query("SELECT * FROM reservations WHERE bookingCode = :code LIMIT 1")
    suspend fun findByCode(code: String): Reservation?

    @Query("SELECT * FROM reservations WHERE unitNumber = :unit AND status != 'لغو شده'")
    suspend fun forUnit(unit: Int): List<Reservation>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(item: Reservation): Long

    @Query("UPDATE reservations SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: Long, status: String)
}
