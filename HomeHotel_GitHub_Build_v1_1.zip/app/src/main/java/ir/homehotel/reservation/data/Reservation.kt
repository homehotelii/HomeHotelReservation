package ir.homehotel.reservation.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reservations")
data class Reservation(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookingCode: String = "",
    val source: String,
    val sourceDetail: String = "",
    val propertyName: String = "ساختمان سیدخندان",
    val propertyId: String = "",
    val unitNumber: Int,
    val guestName: String,
    val guestPhone: String = "",
    val checkInJalali: String,
    val checkOutJalali: String,
    val guestCount: Int,
    val totalAmount: Long,
    val detailLink: String = "",
    val status: String = "در انتظار تأیید",
    val createdAt: Long = System.currentTimeMillis()
)
