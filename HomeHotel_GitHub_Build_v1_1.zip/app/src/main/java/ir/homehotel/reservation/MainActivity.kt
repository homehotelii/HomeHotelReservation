package ir.homehotel.reservation

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.dp
import ir.homehotel.reservation.data.AppDatabase
import ir.homehotel.reservation.data.Reservation
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // ورود پیامک‌ها در این نسخه با Copy & Paste انجام می‌شود؛ دسترسی SMS لازم نیست.
        setContent { HomeHotelApp() }
    }
}

private enum class HomeTab(val title: String) { HOME("رزروها"), CALENDAR("تقویم شمسی"), REPORTS("گزارش‌ها") }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeHotelApp() {
    val context = LocalContext.current
    val dao = remember { AppDatabase.get(context).reservationDao() }
    val reservations by dao.observeAll().collectAsState(initial = emptyList())
    var showForm by remember { mutableStateOf(false) }
    var showBulkImport by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(HomeTab.HOME) }
    val scope = rememberCoroutineScope()
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme {
            Scaffold(
                topBar = { TopAppBar(title = { Column { Text("هوم‌هتل | مدیریت رزرواسیون"); Text("ساختمان سیدخندان · ۴ واحد", style = MaterialTheme.typography.labelSmall) } }) },
                floatingActionButton = {
                    Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        ExtendedFloatingActionButton(onClick = { showBulkImport = true }, text = { Text("ورود گروهی پیامک") }, icon = { Text("▤") })
                        FloatingActionButton(onClick = { showForm = true }) { Text("+") }
                    }
                },
                bottomBar = {
                    NavigationBar {
                        HomeTab.values().forEach { item ->
                            NavigationBarItem(selected = tab == item, onClick = { tab = item }, icon = {
                                Text(when (item) { HomeTab.HOME -> "▤"; HomeTab.CALENDAR -> "▦"; HomeTab.REPORTS -> "▥" }, style = MaterialTheme.typography.titleLarge)
                            }, label = { Text(item.title) })
                        }
                    }
                }
            ) { padding ->
                Column(Modifier.padding(padding).fillMaxSize()) {
                    when (tab) {
                        HomeTab.HOME -> HomeScreen(reservations, onConfirm = { item -> scope.launch {
                            val conflict = dao.forUnit(item.unitNumber).any { old ->
                                old.id != item.id && old.status != "لغو شده" &&
                                    old.checkInJalali < item.checkOutJalali && old.checkOutJalali > item.checkInJalali
                            }
                            if (conflict) message = "تأیید این رزرو ممکن نیست؛ در این واحد رزرو هم‌پوشان دیگری وجود دارد."
                            else { dao.updateStatus(item.id, "قطعی"); message = "رزرو تأیید شد." }
                        } }, onCancel = { item -> scope.launch { dao.updateStatus(item.id, "لغو شده") } })
                        HomeTab.CALENDAR -> CalendarScreen(reservations)
                        HomeTab.REPORTS -> ReportsScreen(reservations)
                    }
                    if (message.isNotBlank()) Text(message, Modifier.padding(horizontal = 16.dp, vertical = 6.dp), color = MaterialTheme.colorScheme.primary)
                }
            }
            if (showForm) ManualReservationDialog(onDismiss = { showForm = false }, onSave = { item ->
                scope.launch {
                    val duplicate = item.bookingCode.isNotBlank() && dao.findByCode(item.bookingCode) != null
                    val overlaps = dao.forUnit(item.unitNumber).any { old ->
                        old.status != "لغو شده" && item.checkInJalali < old.checkOutJalali && item.checkOutJalali > old.checkInJalali
                    }
                    message = when {
                        duplicate -> "این کد رزرو قبلاً ثبت شده است."
                        overlaps -> "برای این واحد در این بازه رزرو دیگری وجود دارد."
                        else -> { dao.insert(item); "رزرو با موفقیت ثبت شد." }
                    }
                    showForm = false
                }
            }) }
            if (showBulkImport) BulkImportDialog(onDismiss = { showBulkImport = false }, onImport = { items ->
                scope.launch {
                    var added = 0
                    var duplicates = 0
                    var conflicts = 0
                    items.forEach { item ->
                        val duplicate = item.bookingCode.isNotBlank() && dao.findByCode(item.bookingCode) != null
                        val overlaps = dao.forUnit(item.unitNumber).any { old ->
                            old.status != "لغو شده" && item.checkInJalali < old.checkOutJalali && item.checkOutJalali > old.checkInJalali
                        }
                        when {
                            duplicate -> duplicates++
                            overlaps -> conflicts++
                            else -> { dao.insert(item); added++ }
                        }
                    }
                    message = "ثبت شد: $added مورد | تکراری: $duplicates مورد | دارای تداخل: $conflicts مورد"
                    showBulkImport = false
                }
            }) }
        }
    }
}

@Composable
private fun HomeScreen(reservations: List<Reservation>, onConfirm: (Reservation) -> Unit, onCancel: (Reservation) -> Unit) {
    val confirmed = reservations.filter { it.status == "قطعی" }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("داشبورد ساختمان سیدخندان", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SummaryCard("کل رزروها", reservations.size.toString(), Modifier.weight(1f))
            SummaryCard("در انتظار تأیید", reservations.count { it.status == "در انتظار تأیید" }.toString(), Modifier.weight(1f))
            SummaryCard("رزرو قطعی", confirmed.size.toString(), Modifier.weight(1f))
        }
        Text("واحدها", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            (1..4).forEach { unit ->
                AssistChip(onClick = { }, label = { Text("واحد $unit · ${reservations.count { it.unitNumber == unit && it.status != "لغو شده" }}") })
            }
        }
        Text("فهرست رزروها", style = MaterialTheme.typography.titleMedium)
        if (reservations.isEmpty()) Text("هنوز رزروی ثبت نشده است.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(reservations, key = { it.id }) { item -> ReservationCard(item, { onConfirm(item) }, { onCancel(item) }) }
        }
    }
}

@Composable
private fun SummaryCard(title: String, value: String, modifier: Modifier = Modifier) {
    ElevatedCard(modifier) { Column(Modifier.padding(10.dp)) { Text(title, style = MaterialTheme.typography.bodySmall); Text(value, style = MaterialTheme.typography.headlineSmall) } }
}

@Composable
private fun ReservationCard(item: Reservation, onConfirm: () -> Unit, onCancel: () -> Unit) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(item.guestName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("واحد ${item.unitNumber}")
            }
            Text("${JalaliDate.persianDigits(item.checkInJalali)} تا ${JalaliDate.persianDigits(item.checkOutJalali)}")
            Text("${item.source}${if (item.sourceDetail.isNotBlank()) " · ${item.sourceDetail}" else ""} · ${item.guestCount} مهمان")
            Text("${money(item.totalAmount)} تومان")
            Text("وضعیت: ${item.status}", style = MaterialTheme.typography.bodySmall)
            if (item.status == "در انتظار تأیید") Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = onConfirm) { Text("تأیید رزرو") }
                TextButton(onClick = onCancel) { Text("لغو") }
            }
        }
    }
}

@Composable
private fun CalendarScreen(reservations: List<Reservation>) {
    val current = remember { JalaliDate.currentYearMonth() }
    var year by remember { mutableIntStateOf(current.first) }
    var month by remember { mutableIntStateOf(current.second) }
    var selected by remember { mutableStateOf(JalaliDate.today()) }
    val dayCount = JalaliDate.daysInMonth(year, month)
    val offset = JalaliDate.firstWeekdayOffset(year, month)
    val cells = (1..(offset + dayCount)).map { if (it <= offset) null else it - offset }
    val weeks = cells.chunked(7).map { it + List(7 - it.size) { null } }
    val activeOnSelected = reservations.filter { it.status != "لغو شده" && it.checkInJalali <= selected && it.checkOutJalali > selected }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("تقویم رزروها", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = {
                    if (month == 1) { month = 12; year-- } else month--
                    selected = JalaliDate.format(year, month, 1)
                }) { Text("‹") }
                Text("${JalaliDate.monthName(month)} ${JalaliDate.persianDigits(year.toString())}", fontWeight = FontWeight.Bold)
                TextButton(onClick = {
                    if (month == 12) { month = 1; year++ } else month++
                    selected = JalaliDate.format(year, month, 1)
                }) { Text("›") }
            }
        }
        Row(Modifier.fillMaxWidth()) {
            listOf("ش", "ی", "د", "س", "چ", "پ", "ج").forEach { Text(it, Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontWeight = FontWeight.Bold) }
        }
        weeks.forEach { week ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                week.forEach { day ->
                    if (day == null) Spacer(Modifier.weight(1f).height(58.dp)) else {
                        val date = JalaliDate.format(year, month, day)
                        val count = reservations.count { it.status != "لغو شده" && it.checkInJalali <= date && it.checkOutJalali > date }
                        val isSelected = selected == date
                        Surface(
                            modifier = Modifier.weight(1f).height(58.dp).clickable { selected = date },
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else if (count > 0) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                            border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary) else null
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                Text(JalaliDate.persianDigits(day.toString()), fontWeight = FontWeight.SemiBold)
                                if (count > 0) Text("${JalaliDate.persianDigits(count.toString())} رزرو", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }
        Divider()
        Text("رزروهای روز ${JalaliDate.persianDigits(selected)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (activeOnSelected.isEmpty()) Text("برای این روز رزروی ثبت نشده است.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(activeOnSelected, key = { it.id }) { r ->
                ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(10.dp)) {
                    Text("${r.guestName} · واحد ${r.unitNumber}", fontWeight = FontWeight.SemiBold)
                    Text("${JalaliDate.persianDigits(r.checkInJalali)} تا ${JalaliDate.persianDigits(r.checkOutJalali)} · ${r.status}")
                } }
            }
        }
    }
}

@Composable
private fun ReportsScreen(reservations: List<Reservation>) {
    val current = remember { JalaliDate.currentYearMonth() }
    var year by remember { mutableIntStateOf(current.first) }
    var month by remember { mutableIntStateOf(current.second) }
    val monthStart = JalaliDate.toEpochDay(JalaliDate.format(year, month, 1)) ?: 0L
    val monthDays = JalaliDate.daysInMonth(year, month)
    val monthEnd = monthStart + monthDays
    val confirmed = reservations.filter { it.status == "قطعی" }
    val monthReservations = reservations.filter { r ->
        val a = JalaliDate.toEpochDay(r.checkInJalali) ?: Long.MAX_VALUE
        val b = JalaliDate.toEpochDay(r.checkOutJalali) ?: Long.MIN_VALUE
        r.status != "لغو شده" && a < monthEnd && b > monthStart
    }
    val income = confirmed.sumOf { r -> revenueInMonth(r, monthStart, monthEnd) }
    val occupiedNights = (1..4).sumOf { unit ->
        confirmed.filter { it.unitNumber == unit }.sumOf { r ->
            val a = JalaliDate.toEpochDay(r.checkInJalali) ?: monthEnd
            val b = JalaliDate.toEpochDay(r.checkOutJalali) ?: monthStart
            (minOf(b, monthEnd) - maxOf(a, monthStart)).coerceAtLeast(0L)
        }
    }
    val capacity = monthDays * 4
    val occupancy = if (capacity == 0) 0 else (occupiedNights * 100 / capacity).toInt()
    val incomeByUnit = (1..4).map { unit -> unit to confirmed.filter { it.unitNumber == unit }.sumOf { revenueInMonth(it, monthStart, monthEnd) } }
    val sources = listOf("اتاقک", "مستقیم", "معرف", "سایت رزرواسیون").map { src -> src to confirmed.filter { it.source == src }.sumOf { revenueInMonth(it, monthStart, monthEnd) } }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("گزارش عملکرد", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { if (month == 1) { month = 12; year-- } else month-- }) { Text("‹") }
                Text("${JalaliDate.monthName(month)} ${JalaliDate.persianDigits(year.toString())}")
                TextButton(onClick = { if (month == 12) { month = 1; year++ } else month++ }) { Text("›") }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SummaryCard("درآمد قطعی", money(income), Modifier.weight(1f))
            SummaryCard("ضریب اشغال", "$occupancy٪", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SummaryCard("شب‌های اشغال", JalaliDate.persianDigits(occupiedNights.toString()), Modifier.weight(1f))
            SummaryCard("رزروهای درگیر در ماه", JalaliDate.persianDigits(monthReservations.size.toString()), Modifier.weight(1f))
        }
        Text("درآمد به تفکیک واحد", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        incomeByUnit.forEach { (unit, amount) -> ReportLine("واحد $unit", money(amount) + " تومان") }
        Text("درآمد به تفکیک منبع", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        sources.forEach { (source, amount) -> ReportLine(source, money(amount) + " تومان") }
        Text("مبنای محاسبه: فقط رزروهای قطعی در درآمد و ضریب اشغال لحاظ می‌شوند. رزروهای لغوشده محاسبه نمی‌شوند.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private fun revenueInMonth(r: Reservation, start: Long, end: Long): Long {
    val a = JalaliDate.toEpochDay(r.checkInJalali) ?: return 0L
    val b = JalaliDate.toEpochDay(r.checkOutJalali) ?: return 0L
    val totalNights = (b - a).coerceAtLeast(0L)
    if (totalNights == 0L) return 0L
    val nightsInMonth = (minOf(b, end) - maxOf(a, start)).coerceAtLeast(0L)
    return (r.totalAmount * nightsInMonth) / totalNights
}

private fun overlapsMonth(r: Reservation, start: Long, end: Long): Boolean {
    val a = JalaliDate.toEpochDay(r.checkInJalali) ?: return false
    val b = JalaliDate.toEpochDay(r.checkOutJalali) ?: return false
    return a < end && b > start
}

@Composable
private fun ReportLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun BulkImportDialog(onDismiss: () -> Unit, onImport: (List<Reservation>) -> Unit) {
    var raw by remember { mutableStateOf("") }
    var parsed by remember { mutableStateOf<List<Reservation>>(emptyList()) }
    var errors by remember { mutableStateOf(0) }
    var analyzed by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ورود گروهی پیامک‌های اتاقک") },
        text = {
            Column(Modifier.heightIn(max = 560.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("متن یک یا چند پیامک تأیید رزرو را کپی و در کادر زیر Paste کنید.", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(
                    value = raw,
                    onValueChange = { raw = it; analyzed = false },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 130.dp, max = 210.dp),
                    placeholder = { Text("اتاقک-تایید رزرو\\nرزرو با کد ...") },
                    minLines = 5
                )
                Button(onClick = {
                    val result = parsePastedBookings(raw)
                    parsed = result.first
                    errors = result.second
                    analyzed = true
                }, enabled = raw.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("استخراج و پیش‌نمایش") }
                if (analyzed) {
                    Text("قابل شناسایی: ${JalaliDate.persianDigits(parsed.size.toString())} رزرو · ناموفق: ${JalaliDate.persianDigits(errors.toString())}", fontWeight = FontWeight.Bold)
                    if (parsed.isEmpty()) Text("رزروی از متن واردشده استخراج نشد. متن پیامک اتاقک را بررسی کنید.", color = MaterialTheme.colorScheme.error)
                    LazyColumn(Modifier.heightIn(max = 210.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(parsed) { r ->
                            ElevatedCard(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(9.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text("${r.guestName} · واحد ${r.unitNumber}", fontWeight = FontWeight.SemiBold)
                                    Text("کد ${JalaliDate.persianDigits(r.bookingCode)} · ${JalaliDate.persianDigits(r.checkInJalali)} تا ${JalaliDate.persianDigits(r.checkOutJalali)}")
                                    Text("${JalaliDate.persianDigits(r.guestCount.toString())} مهمان · ${money(r.totalAmount)} تومان")
                                }
                            }
                        }
                    }
                    Text("رزروها پس از ثبت، در وضعیت «در انتظار تأیید» قرار می‌گیرند.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onImport(parsed) }, enabled = analyzed && parsed.isNotEmpty()) { Text("ثبت ${parsed.size} رزرو") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("بستن") } }
    )
}

private fun parsePastedBookings(raw: String): Pair<List<Reservation>, Int> {
    val normalized = JalaliDate.normalizeDigits(raw)
    val starts = Regex("(?=اتاقک\\s*[-–—]?\\s*تایید\\s*رزرو)").findAll(normalized).map { it.range.first }.toList()
    val chunks = if (starts.isEmpty()) listOf(normalized) else starts.mapIndexed { index, start -> normalized.substring(start, starts.getOrNull(index + 1) ?: normalized.length) }
    val valid = mutableListOf<Reservation>()
    var failed = 0
    chunks.filter { it.contains("رزرو با کد") }.forEach { block ->
        fun field(label: String): String = Regex("(?m)^${Regex.escape(label)}\\s*:\\s*(.*)$").find(block)?.groupValues?.get(1)?.trim().orEmpty()
        val code = Regex("رزرو با کد\\s*(\\d+)").find(block)?.groupValues?.get(1).orEmpty()
        val property = field("نام اقامتگاه")
        val unit = Regex("\\((\\d+)\\)\\s*$").find(property)?.groupValues?.get(1)?.toIntOrNull()
        val start = field("تاریخ ورود")
        val end = field("تاریخ خروج")
        val guest = field("نام مهمان")
        val amount = Regex("مبلغ\\s*(\\d+)\\s*تومان").find(block)?.groupValues?.get(1)?.toLongOrNull()
        val count = field("تعداد مهمان").toIntOrNull() ?: 1
        val validDates = JalaliDate.toEpochDay(start) != null && JalaliDate.toEpochDay(end) != null &&
            (JalaliDate.toEpochDay(end) ?: 0L) > (JalaliDate.toEpochDay(start) ?: Long.MAX_VALUE)
        if (code.isBlank() || unit == null || unit !in 1..4 || guest.isBlank() || !validDates || amount == null) {
            failed++
        } else {
            valid += Reservation(
                bookingCode = code, source = "اتاقک", sourceDetail = "اتاقک",
                propertyName = "ساختمان سیدخندان", propertyId = field("شناسه اقامتگاه"),
                unitNumber = unit!!, guestName = guest, guestPhone = field("شماره همراه مهمان"),
                checkInJalali = start, checkOutJalali = end, guestCount = count,
                totalAmount = amount, detailLink = field("جزئیات رزرو"), status = "در انتظار تأیید"
            )
        }
    }
    return valid to (failed + if (chunks.none { it.contains("رزرو با کد") } && raw.isNotBlank()) 1 else 0)
}

@Composable
private fun ManualReservationDialog(onDismiss: () -> Unit, onSave: (Reservation) -> Unit) {
    var source by remember { mutableStateOf("مستقیم") }
    var sourceDetail by remember { mutableStateOf("") }
    var guest by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("4") }
    var start by remember { mutableStateOf(JalaliDate.today()) }
    var end by remember { mutableStateOf(JalaliDate.addDays(JalaliDate.today(), 1)) }
    var count by remember { mutableStateOf("1") }
    var amount by remember { mutableStateOf("0") }
    var code by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("ثبت رزرو دستی") }, text = {
        Column(Modifier.heightIn(max = 560.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("منبع رزرو")
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf("مستقیم", "معرف", "سایت رزرواسیون").forEach { option ->
                    FilterChip(selected = source == option, onClick = { source = option }, label = { Text(option) })
                }
            }
            OutlinedTextField(value = sourceDetail, onValueChange = { sourceDetail = it }, label = { Text("نام معرف یا سایت (در صورت نیاز)") }, singleLine = true)
            OutlinedTextField(value = guest, onValueChange = { guest = it }, label = { Text("نام مهمان") }, singleLine = true)
            OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("شماره همراه") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true)
            OutlinedTextField(value = unit, onValueChange = { unit = JalaliDate.normalizeDigits(it).filter(Char::isDigit).take(1) }, label = { Text("شماره واحد (۱ تا ۴)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            OutlinedTextField(value = start, onValueChange = { start = JalaliDate.normalizeDigits(it) }, label = { Text("تاریخ ورود شمسی") }, singleLine = true)
            OutlinedTextField(value = end, onValueChange = { end = JalaliDate.normalizeDigits(it) }, label = { Text("تاریخ خروج شمسی") }, singleLine = true)
            OutlinedTextField(value = count, onValueChange = { count = JalaliDate.normalizeDigits(it).filter(Char::isDigit) }, label = { Text("تعداد مهمان") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            OutlinedTextField(value = amount, onValueChange = { amount = JalaliDate.normalizeDigits(it).filter(Char::isDigit) }, label = { Text("مبلغ کل (تومان)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            OutlinedTextField(value = code, onValueChange = { code = it }, label = { Text("کد رزرو (اختیاری)") }, singleLine = true)
            if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
    }, confirmButton = { TextButton(onClick = {
        val u = unit.toIntOrNull() ?: 0
        val startDay = JalaliDate.toEpochDay(start)
        val endDay = JalaliDate.toEpochDay(end)
        when {
            guest.isBlank() -> error = "نام مهمان را وارد کنید."
            u !in 1..4 -> error = "شماره واحد باید بین ۱ تا ۴ باشد."
            startDay == null || endDay == null -> error = "تاریخ شمسی معتبر وارد کنید."
            endDay <= startDay -> error = "تاریخ خروج باید بعد از تاریخ ورود باشد."
            else -> onSave(Reservation(bookingCode = code, source = source, sourceDetail = sourceDetail, unitNumber = u, guestName = guest, guestPhone = phone, checkInJalali = start, checkOutJalali = end, guestCount = count.toIntOrNull() ?: 1, totalAmount = amount.toLongOrNull() ?: 0L, status = "قطعی"))
        }
    }) { Text("ذخیره") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } })
}

private fun money(value: Long): String = String.format(Locale.US, "%,d", value).let(JalaliDate::persianDigits)
